package Lab4;

/**
 * @author Alex Han
 */

/**
 * Employee Class implements Employable,Comparable
 */
public abstract class Employee implements Employable,Comparable{
    String name;

    /**
     * Abstract
     * @return nothing
     */
    public abstract double getOverTimePayRate();

    /**
     * getter
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * setter
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * constructor
     * @param name needed name to instantiate
     */
    public Employee(String name) {
        this.name = name;
    }
}
