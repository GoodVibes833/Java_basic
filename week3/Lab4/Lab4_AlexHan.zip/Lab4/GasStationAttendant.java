package Lab4;

/**
 * @author AlexHan
 */

/**
 * GasStationAttendant class
 */
public class GasStationAttendant extends Employee{
    /**
     * variables
     */
    double numberOfDollarsStolenPerDay;

    /**
     * GasStationAttendant
     * @param name name
     * @param numberOfDollarsStolenPerDay numberOfDollarsStolenPerDay
     */
    public GasStationAttendant(String name, double numberOfDollarsStolenPerDay) {
        super(name);
        this.numberOfDollarsStolenPerDay = numberOfDollarsStolenPerDay;
    }

    /**
     *
     * @return 1.5
     */
    public double getOverTimePayRate(){
        return  1.5;
    }

    /**
     *
     * @return numberOfDollarsStolenPerDay
     */
    public double getNumberOfDollarsStolenPerDay() {
        return numberOfDollarsStolenPerDay;
    }

    /**
     *
     * @return enum type UNIFORM
     */
    @Override
    public DressCode getDressCode() {
        return DressCode.UNIFORM;
    }

    /**
     *
     * @return false
     */
    @Override
    public boolean isPaidSalary() {
        return false;
    }

    /**
     *
     * @return false
     */
    @Override
    public boolean postSecondaryEducationRequired() {
        return false;
    }

    /**
     *
     * @return classname, name, numberOfDollarsStolenPerDay
     */
    @Override
    public String toString() {
        return String.format("%-20s %-20s steals %3d dollars a day.","GasStationAttendant",name,(int)numberOfDollarsStolenPerDay);

    }

    /**
     *
     * @return pump
     */
    @Override
    public String getWorkVerb() {
        return "pump";
    }

    /**
     *
     * @param gs
     * @return ascending order
     */
    public int compareTo(Object gs) {

        int compareQuantity = (int) ((GasStationAttendant)gs).getNumberOfDollarsStolenPerDay();

        //ascending order
        return (int) (this.numberOfDollarsStolenPerDay - compareQuantity);

        //descending order
//        return (int) (compareQuantity - this.numberOfDollarsStolenPerDay);

    }

    /**
     *
     * @param obj
     * @return true or false
     */
    @Override
    public boolean equals(Object obj) {
        if(this == obj){
            return true;
        }if(obj==null){
            return false;
        }if(obj.getClass() != this.getClass()){
            return true;
        }if (this.getNumberOfDollarsStolenPerDay() ==((GasStationAttendant)obj).getNumberOfDollarsStolenPerDay()){
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result =1;
        result = (int) (prime + result +getNumberOfDollarsStolenPerDay());
        return  result;
    }




}