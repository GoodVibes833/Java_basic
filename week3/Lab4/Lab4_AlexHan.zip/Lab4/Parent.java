package Lab4;

/**
 * @author AlexHan
 */

/**
 * Parent Class
 */
public class Parent extends Employee {
    /**
     * variables
     */
    int numberOfHoursSpentPerWeekWithKids;

    /**
     * Constructor
     * @param name
     * @param numberOfHoursSpentPerWeekWithKids
     */
    public Parent(String name, int numberOfHoursSpentPerWeekWithKids) {
        super(name);
        this.numberOfHoursSpentPerWeekWithKids = numberOfHoursSpentPerWeekWithKids;
    }

    /**
     * getOverTimePayRate
     * @return -2
     */
    public double getOverTimePayRate(){
        return  -2.0;
    }

    /**
     * getDressCode
     * @return enum type ANYTHING
     */
    @Override
    public DressCode getDressCode() {
        return DressCode.ANYTHING;
    }

    /**
     * getNumberOfHoursSpentPerWeekWithKids
     * @return numberOfHoursSpentPerWeekWithKids
     */
    public int getNumberOfHoursSpentPerWeekWithKids() {
        return numberOfHoursSpentPerWeekWithKids;
    }

    /**
     * isPaidSalary
     * @return false
     */
    @Override
    public boolean isPaidSalary() {
        return false;
    }

    /**
     * postSecondaryEducationRequired
     * @return false
     */
    @Override
    public boolean postSecondaryEducationRequired() {
        return false;
    }

    /**
     * toString
     * @return className(Parent),name,numberOfHoursSpentPerWeekWithKids
     */
    @Override
    public String toString() {
        return String.format("%-20s %-20s spends %3d  hours/week with kids.","Parent",name,numberOfHoursSpentPerWeekWithKids);
    }

    /**
     * getWorkVerb
     * @return care
     */
    @Override
    public String getWorkVerb() {
        return "care";
    }

    /**
     * compareTo
     * @param pa
     * @return returns  ascending order
     */
    public int compareTo(Object pa) {

        int compareQuantity = ((Parent)pa).getNumberOfHoursSpentPerWeekWithKids();

        //ascending order
            return this.numberOfHoursSpentPerWeekWithKids - compareQuantity;

        //descending order
//        return compareQuantity - this.numberOfHoursSpentPerWeekWithKids;

    }


    @Override
    public boolean equals(Object obj) {
        if(this == obj){
            return true;
        }if(obj==null){
            return false;
        }if(obj.getClass() != this.getClass()){
            return true;
        }if (this.getNumberOfHoursSpentPerWeekWithKids() ==((Parent)obj).getNumberOfHoursSpentPerWeekWithKids()){
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result =1;
        result = prime + result +getNumberOfHoursSpentPerWeekWithKids();
        return  result;
    }


}