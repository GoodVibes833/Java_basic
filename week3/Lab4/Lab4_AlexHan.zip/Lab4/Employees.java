package Lab4;

import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Collections;

/**
 * @author Alex Han
 */

/**
 * Employees class that instantiate new classes
 */
public class Employees {
    public static void main(String[] args) {


        ArrayList<HockeyPlayer> hp = new ArrayList<HockeyPlayer>();
        HockeyPlayer hp1 = new HockeyPlayer("Wayne Gretzky", 894);
        HockeyPlayer hp2 = new HockeyPlayer("Wayne Gretzky", 894);
        HockeyPlayer hp3 = new HockeyPlayer("Who Ever", 0);
        hp.add(hp1);
        hp.add(hp2);
        hp.add(hp3);
        hp.add(new HockeyPlayer("Brent Gretzky", 1));
        hp.add(new HockeyPlayer("Pavel Bure", 437));
        hp.add(new HockeyPlayer("Jason Bourne", 0));


        ArrayList<Professor> pr = new ArrayList<Professor>();
        Professor pr1 = new Professor("Albert Einstein", "Physics");
        pr.add(pr1);
        pr.add(new Professor("Alan Turing", "Computer Systems"));
        pr.add(new Professor("Richard Feynman", "Physics"));
        pr.add(new Professor("Tim Berners-Lee", "Computer Systems"));
        pr.add(new Professor("Kurt Godel", "Logic"));

        ArrayList<Parent> pa = new ArrayList<Parent>();
        Parent pa1 = new Parent("Tiger Woods", 1);
        pa.add(pa1);
        pa.add(new Parent("Super Mom", 168));
        pa.add(new Parent("Lazy Larry", 20));
        pa.add(new Parent("Ex Hausted", 168));
        pa.add(new Parent("Super Dad", 167));

        ArrayList<GasStationAttendant> gs = new ArrayList<GasStationAttendant>();
        gs.add(new GasStationAttendant("Joe Smith", 10));
        gs.add(new GasStationAttendant("Tony Baloney", 100));
        gs.add(new GasStationAttendant("Benjamin Franklin", 100));
        gs.add(new GasStationAttendant("Mary Fairy", 101));
        gs.add(new GasStationAttendant("Bee See", 1));


        Collections.sort(hp);
        Collections.sort(pr);
        Collections.sort(pa);
        Collections.sort(gs);

        System.out.println();
        for(HockeyPlayer hk: hp){
            System.out.println(hk);
        }
        System.out.println("-----------------------------------------------------");
        for(Professor hk: pr){
            System.out.println(hk);
        }
        System.out.println("-----------------------------------------------------");
        for(Parent hk: pa){
            System.out.println(hk);
        }
        System.out.println("-----------------------------------------------------");
        for(GasStationAttendant hk: gs){
            System.out.println(hk);
        }
        System.out.println("-----------------------------------------------------");

        System.out.println(hp1.equals(hp2)); // true
        System.out.println(hp2.equals(hp3)); // false

//        System.out.println(hp1.equals(pr1)); // true. ?
//        System.out.println(hp1.equals(pa1)); // true. ?





    }}
