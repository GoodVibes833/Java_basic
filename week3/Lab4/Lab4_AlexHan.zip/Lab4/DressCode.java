package Lab4;

/**
 * @author Alex Han
 */

/**
 * DressCode Enum
 */
public enum DressCode {

    JERSEY("jersey"), FANCY("fancy"), ANYTHING("anything"), UNIFORM("uniform");

    DressCode(String str) {
    }
}
