package Lab4;

/**
 * @author Alex Han
 */

/**
 * Professor Class
 */
public class Professor extends Employee {
    /**
     * variables
     */
    String teachingMajor;

    /**
     * constructor
     * @param name
     * @param teachingMajor
     */
    public Professor(String name, String teachingMajor) {
        super(name);
        this.teachingMajor = teachingMajor;
    }

    /**
     * getOverTimePayRate
     * @return 2
     */
   public double getOverTimePayRate(){
        return  2.0;
    }

    /**
     * getTeachingMajor
     * @return teachingMajor
     */
    public String getTeachingMajor() {
        return teachingMajor;
    }

    /**
     * getDressCode
     * @return enum type FANCY
     */
    @Override
    public DressCode getDressCode() {
        return DressCode.FANCY;
    }

    /**
     * isPaidSalary
     * @return true
     */
    @Override
    public boolean isPaidSalary() {
        return true;
    }

    /**
     * postSecondaryEducationRequired
     * @return true
     */
    @Override
    public boolean postSecondaryEducationRequired() {
        return true;
    }

    /**
     * toString
     * @return className(Professor), name, teachingMajor
     */
    @Override
    public String toString() {
        return String.format("%-20s %-20s teachs %-10s","Professor",name,teachingMajor);
    }

    /**
     * getWorkVerb
     * @return teach
     */
    @Override
    public String getWorkVerb() {
        return "teach";
    }


//    public int compareTo(Professor pr) {
//
//        String compareQuantity = pr.getTeachingMajor();
//
//        //ascending order
////            return this.numberOfGoals - compareQuantity;
//
//        //descending order
//        return  compareQuantity - this.teachingMajor;
//
//    }

    /**
     * compareTo
     * @param pr
     * @return the ascending order

     */
        public int compareTo(Object pr) {

        if("Physics" ==((Professor)pr).getTeachingMajor()){
            return 0;
        }else
            return -1;
    }

    /**
     * equals
     * @param obj
     * @return true or false
     */
    @Override
    public boolean equals(Object obj) {
        if(this == obj){
            return true;
        }if(obj==null){
            return false;
        }if(obj.getClass() != this.getClass()){
            return true;
        }if (this.getTeachingMajor() ==((Professor)obj).getTeachingMajor()){
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result =1;
        result = prime + result ;
        return  result;
    }
}

