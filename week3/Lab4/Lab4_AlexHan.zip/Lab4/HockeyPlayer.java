package Lab4;

/**
 * @author Alex Han
 */

/**
 * HockeyPlayer Class
 */
public class HockeyPlayer extends Employee{
    /**
     * variable
     */
    int numberOfGoals;

    /**
     * Constructor
     * @param name
     * @param numberOfGoals
     */
    public HockeyPlayer(String name, int numberOfGoals) {
        super(name);
        this.numberOfGoals = numberOfGoals;
    }

    /**
     * getOverTimePayRate
     * @return 0
     */
    public double getOverTimePayRate(){
        return  0.0;
    }

    /**
     * getDressCode
     * @return enum type
     */
    @Override
    public DressCode getDressCode() {
        return DressCode.JERSEY;
    }

    /**
     * isPaidSalary
     * @return true
     */
    @Override
    public boolean isPaidSalary() {
        return true;
    }

    /**
     * postSecondaryEducationRequired
     * @return false
     */
    @Override
    public boolean postSecondaryEducationRequired() {
        return false;
    }

    /**
     * getWorkVerb
     * @return String play
     */
    @Override
    public String getWorkVerb() {
        return "play";
    }

    /**
     * getNumberOfGoals
     * @return numberOfGoals
     */
    public int getNumberOfGoals() {
        return numberOfGoals;
    }

    /**
     * toString
     * @return className(HockeyPlayer), name , numberOfGoals
     */
    @Override
    public String toString() {

    return String.format("%-20s %-20s score %3d goals","HockeyPlayer",name,numberOfGoals);
    }


    /**
     * CompareTo :used for ascending order
     * @param hk
     * @return the different values
     */
    public int compareTo(Object hk) {

            int compareQuantity = ((HockeyPlayer)hk).getNumberOfGoals();

            //ascending order
            return this.numberOfGoals - compareQuantity;

            //descending order
//            return compareQuantity - this.numberOfGoals;

        }

//  true, if this == that
//• false, if that == null
//• false, if that is not an instanceof the same class (.getClass() != .getClass())

//• true for HockeyPlayers if and only if they score the same number of goals
//• true for Professors if and only if they teach the same subject
//• true for Parents if and only if they parent the same number of hours
//• true for GasStationAttendants if and only if they steal the same amount.

    /**
     * equals
     * @param obj
     * @return true or not
     */
    @Override
    public boolean equals(Object obj) {
        if(this == obj){
            return true;
        }if(obj==null){
            return false;
        }if(obj.getClass() != this.getClass()){
            return true;
        }if (this.getNumberOfGoals() ==((HockeyPlayer)obj).getNumberOfGoals()){
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result =1;
        result = prime + result +this.getNumberOfGoals();
        return  result;
    }
}

