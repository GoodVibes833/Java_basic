package Lab2;

/**
 * @author Alex Han
 */

/**
 * Driver class to create Country class
 */
public class Driver {
    public static void main(String[] args) {
        Country ca = new Country();
        ca.displayAllProvinces();
        ca.howManyHaveThisPopulation(2,5);


    }
}
