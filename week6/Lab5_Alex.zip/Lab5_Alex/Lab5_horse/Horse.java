package Lab5_horse;

/**
 * @author Alex Han
 */
public interface Horse {

    String getName();

    int getWeight();








}
